﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {
  public bool candoubleJump;
  public float speed =50f;
  public float jumpPower =150f;
  public float MaxSpeed = 3;
  public bool grounded;
  private Animator anim; 
  private Rigidbody2D rb2D;
	// Use this for initialization
	void Start ()
	{
	  rb2D = gameObject.GetComponent<Rigidbody2D>();
	  anim = gameObject.GetComponent<Animator>();
	}
	void Update()
    {
		anim.SetBool("Grounded",grounded);
		anim.SetFloat("Speed",Mathf.Abs(Input.GetAxis("Horizontal")));
		
		if(Input.GetAxis("Horizontal") < -0.1f)
		{
			transform.localScale = new Vector3(-1,1,1);
		}
		if(Input.GetAxis("Horizontal") > 0.1f)
		{
			transform.localScale = new Vector3(1,1,1);
		}
		if(Input.GetButtonDown("Jump"))
		{
			if(grounded)
			{
			rb2D.AddForce(Vector2.up * jumpPower);
			candoubleJump = true;
			}else{
				if(candoubleJump)
				{
					candoubleJump = false;
					rb2D.velocity =new Vector2(rb2D.velocity.x,0);
					rb2D.AddForce(Vector2.up * jumpPower);
					
				}
			}
			
			
		}
	}
	
	// Update is called once per frame
	void FixedUpdate () 
	{
		// Movin The Player
	  float h = Input.GetAxis("Horizontal");
	  
	  
	  // limiting the speed of the player 
	  rb2D.AddForce((Vector2.right * speed) * h);
	  
	  if(rb2D.velocity.x > MaxSpeed)
	  {
		  rb2D.velocity = new Vector2(MaxSpeed,rb2D.velocity.y);
	  }
	  if(rb2D.velocity.x < - MaxSpeed)
	  {
		  rb2D.velocity = new Vector2(-MaxSpeed, rb2D.velocity.y); 
	  }
	}
}
